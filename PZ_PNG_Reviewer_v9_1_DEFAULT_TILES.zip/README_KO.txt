좀보이드 PNG 타일셋 이미지 검수기 v9.1 — Tiles 기본 경로 자동 인식

1. 이 ZIP을 압축 해제합니다.
2. PZ_PNG_Tileset_Reviewer_v9_1_DEFAULT_TILES.html 파일을 기존 Tiles 폴더와 같은 폴더에 둡니다.
3. HTML을 Chrome/Edge에서 실행합니다.
4. 프로그램에 내장된 406개 PNG 상대 경로(Tiles/...)를 사용해 목록과 미리보기를 불러옵니다.
5. PNG 목록에서 '검수 열기'를 눌러 정체·속성·재질 등을 검수합니다.
6. 자동 저장 기능을 사용하며, 전체 중간저장 JSON을 주기적으로 내려받습니다.

폴더 예:
PZ_PNG_Tileset_Reviewer_v9_1_DEFAULT_TILES.html
Tiles/
  2x/
    advertising_01.png
    appliances_com_01.png
    ...
  vegetation_foliage_01.png
  ...

PNG 원본 파일은 이 ZIP에 포함되지 않습니다.
폴더 구조나 PNG 이름이 다르면 원본을 선택해서 수동 등록하거나 경로를 맞춰야 합니다.
파일을 다른 브라우저/PC로 옮길 때는 전체 중간저장 JSON을 별도 보관하세요.
